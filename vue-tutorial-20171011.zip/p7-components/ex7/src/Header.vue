<template>
  <div id="header">
    <div class="row">
        <div class="col-xs-12">
            <header>
                <h1>Server Status</h1>
            </header>
        </div>
    </div>
  </div>
</template>

<script>
export default {
  name: '#header',
  data() {

  },
  methods: {

  }
}
</script>

<style>
</style>